using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class EnemyMultiplayerController : MonoBehaviourPun
{
    [Header("Detección")]
    [SerializeField] private float detectionRange = 100f;

    [Header("Vida")]
    [SerializeField] private float maxLife = 100f;
    private float life;

    [Header("Daño")]
    [SerializeField] private float damage = 10f;
    [SerializeField] private float attackCooldown = 1f;

    private NavMeshAgent agent;
    private Animator animator;
    private Transform target;
    private bool playerInRange = false;
    private float attackTimer = 0f;
    private bool isDead = false;

    // SpawnManager se suscribe a este evento
    public event Action<GameObject> OnDeath;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
        life = maxLife;

        // Solo el MasterClient controla la IA del enemigo
        if (PhotonNetwork.IsMasterClient)
            InvokeRepeating(nameof(BuscarJugadorMasCercano), 0f, 1f);
    }

    void Update()
    {
        // Solo el MasterClient mueve y ataca
        if (PhotonNetwork.IsMasterClient == false) return;
        if (isDead) return;
        if (target == null)
        {
            BuscarJugadorMasCercano();
            return;
        }

        // Rotar hacia el jugador
        Vector3 direction = (target.position - transform.position).normalized;
        direction.y = 0f;
        if (direction != Vector3.zero)
            transform.rotation = Quaternion.LookRotation(direction);

        animator.SetBool("PlayerDetected", true);

        if (!playerInRange)
            agent.SetDestination(target.position);

        if (attackTimer > 0f)
            attackTimer -= Time.deltaTime;

        if (playerInRange && attackTimer <= 0f)
            AttackPlayer();
    }

    // ── IA ─────────────────────────────────────────────────────

    void BuscarJugadorMasCercano()
    {
        if (isDead) return;

        GameObject[] players = GameObject.FindGameObjectsWithTag("Player");
        float minDist = Mathf.Infinity;
        Transform closest = null;

        foreach (GameObject p in players)
        {
            if (p.activeInHierarchy == false) continue;
            float dist = Vector3.Distance(transform.position, p.transform.position);
            if (dist < minDist)
            {
                minDist = dist;
                closest = p.transform;
            }
        }

        target = closest;
    }

    private void AttackPlayer()
    {
        attackTimer = attackCooldown;
        if (target == null) return;

        // El daño se aplica via RPC en el cliente del jugador
        PhotonView targetView = target.GetComponent<PhotonView>();
        if (targetView != null)
            photonView.RPC("RPC_DamagePlayer", targetView.Owner, damage);
    }

    [PunRPC]
    void RPC_DamagePlayer(float dmg)
    {
        // Este RPC llega al cliente dueño del jugador
        if (target == null) return;
        MultiplayerController playerHealth = target.GetComponent<MultiplayerController>();
        if (playerHealth != null && playerHealth.photonView.IsMine)
            playerHealth.TakeDamage(dmg, null);
    }

    // ── TRIGGERS ───────────────────────────────────────────────

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("PlayerRange"))
        {
            playerInRange = true;
            animator.SetBool("PlayerInRange", true);
            if (PhotonNetwork.IsMasterClient)
                agent.isStopped = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("PlayerRange"))
        {
            playerInRange = false;
            animator.SetBool("PlayerInRange", false);
            if (PhotonNetwork.IsMasterClient)
                agent.isStopped = false;
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRange);
    }

    // ── DAÑO Y MUERTE ──────────────────────────────────────────

    public void TakeDamage(float dmg, Player owner)
    {
        // Solo el MasterClient gestiona la vida del enemigo
        if (PhotonNetwork.IsMasterClient == false) return;
        if (isDead) return;

        life -= dmg;
        Debug.Log($"[Enemy] Vida restante: {life}");

        if (life <= 0f)
            photonView.RPC("RPC_EnemyDead", RpcTarget.All);
    }

    [PunRPC]
    public void RPC_EnemyDead()
    {
        if (isDead) return;

        isDead = true;
        Debug.Log("[Enemy] Muerto");

        if (agent != null) agent.isStopped = true;
        animator.SetTrigger("Muerte");

        OnDeath?.Invoke(gameObject);

        StartCoroutine(DeactivateAfterAnimation());
    }

    private IEnumerator DeactivateAfterAnimation()
    {
        yield return null;

        AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        while (!stateInfo.IsName("Muerte"))
        {
            yield return null;
            stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        }

        yield return new WaitForSeconds(stateInfo.length);

        // Solo el MasterClient destruye el objeto en la red
        if (PhotonNetwork.IsMasterClient)
            PhotonNetwork.Destroy(gameObject);
        else
            gameObject.SetActive(false);
    }
}
