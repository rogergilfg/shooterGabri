using UnityEngine;

public class CameraMultiplayerController : MonoBehaviour
{
    private Transform player;
    public Vector3 camOffset;

    void LateUpdate()
    {
        if (player == null) return;
        transform.position = player.position + camOffset;
    }

    public void SetPlayer(Transform _player)
    {
        player = _player;
    }
}
